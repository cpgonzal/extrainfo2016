## Source
https://github.com/jkthompson/pyspark-pictures

## References
[pyspark API](http://spark.apache.org/docs/1.2.0/api/python/index.html)

## Contribute
Contributors are welcome  
Original images are [here](https://docs.google.com/presentation/d/1VFX9WMHcYiDidWdY_uYbBIFqYjG6joxN817Y6l-jD5w/edit?usp=sharing), download to pdf, convert to svg with: genSVD (pdf2svg)
